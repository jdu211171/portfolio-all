--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE jdu;
--
-- Name: jdu; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE jdu WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE jdu OWNER TO postgres;

\connect jdu

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_Decans_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Decans_role" AS ENUM (
    'decan'
);


ALTER TYPE public."enum_Decans_role" OWNER TO postgres;

--
-- Name: enum_Groups_year; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Groups_year" AS ENUM (
    'First',
    'Second',
    'Third',
    'Fourth'
);


ALTER TYPE public."enum_Groups_year" OWNER TO postgres;

--
-- Name: enum_JapanLanguageTests_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_JapanLanguageTests_level" AS ENUM (
    '0',
    'N1',
    'N2',
    'N3',
    'N4',
    'N5',
    'Q1',
    'Q2',
    'Q3',
    'Q4'
);


ALTER TYPE public."enum_JapanLanguageTests_level" OWNER TO postgres;

--
-- Name: enum_JapanLanguageTests_name; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_JapanLanguageTests_name" AS ENUM (
    'JLPT',
    'NAT'
);


ALTER TYPE public."enum_JapanLanguageTests_name" OWNER TO postgres;

--
-- Name: enum_LessonResults_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_LessonResults_status" AS ENUM (
    'Incompleted',
    'Completed'
);


ALTER TYPE public."enum_LessonResults_status" OWNER TO postgres;

--
-- Name: enum_Parents_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Parents_role" AS ENUM (
    'parent'
);


ALTER TYPE public."enum_Parents_role" OWNER TO postgres;

--
-- Name: enum_Recruitors_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Recruitors_role" AS ENUM (
    'recruitor'
);


ALTER TYPE public."enum_Recruitors_role" OWNER TO postgres;

--
-- Name: enum_Students_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Students_role" AS ENUM (
    'student'
);


ALTER TYPE public."enum_Students_role" OWNER TO postgres;

--
-- Name: enum_Teachers_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Teachers_role" AS ENUM (
    'teacher',
    'staff'
);


ALTER TYPE public."enum_Teachers_role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Credits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Credits" (
    id uuid NOT NULL,
    "lessonName" character varying(255) NOT NULL,
    university character varying(255) NOT NULL,
    credit integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Credits" OWNER TO postgres;

--
-- Name: Decans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Decans" (
    id uuid NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255),
    "loginId" character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    role public."enum_Decans_role" DEFAULT 'decan'::public."enum_Decans_role" NOT NULL,
    avatar character varying(255),
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Decans" OWNER TO postgres;

--
-- Name: Groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Groups" (
    id uuid NOT NULL,
    name character varying(255),
    collection character varying(255) DEFAULT 'IT'::character varying,
    year public."enum_Groups_year" DEFAULT 'First'::public."enum_Groups_year",
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Groups" OWNER TO postgres;

--
-- Name: Infos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Infos" (
    id uuid NOT NULL,
    "phoneNumber" character varying(255) DEFAULT '+998 98 876 54 32'::character varying,
    "startTime" character varying(255) DEFAULT '09:00'::character varying,
    "endTime" character varying(255) DEFAULT '21:00'::character varying,
    location character varying(255) DEFAULT 'Tashkent, Shayhontohur district, Sebzor, 21'::character varying,
    "emailInfo" character varying(255)
);


ALTER TABLE public."Infos" OWNER TO postgres;

--
-- Name: ItQualificationResults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ItQualificationResults" (
    id uuid NOT NULL,
    procent integer NOT NULL,
    "ItQualificationId" uuid NOT NULL,
    "skillId" uuid NOT NULL
);


ALTER TABLE public."ItQualificationResults" OWNER TO postgres;

--
-- Name: ItQualifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ItQualifications" (
    id uuid NOT NULL,
    description text,
    "studentId" uuid NOT NULL
);


ALTER TABLE public."ItQualifications" OWNER TO postgres;

--
-- Name: JapanLanguageTests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."JapanLanguageTests" (
    id uuid NOT NULL,
    name public."enum_JapanLanguageTests_name" NOT NULL,
    level public."enum_JapanLanguageTests_level" DEFAULT '0'::public."enum_JapanLanguageTests_level",
    listening integer,
    reading integer,
    writing integer,
    sertificate character varying(255),
    "studentId" uuid NOT NULL
);


ALTER TABLE public."JapanLanguageTests" OWNER TO postgres;

--
-- Name: LessonResults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LessonResults" (
    id uuid NOT NULL,
    status public."enum_LessonResults_status" NOT NULL,
    "semesterId" uuid NOT NULL,
    "creditId" uuid
);


ALTER TABLE public."LessonResults" OWNER TO postgres;

--
-- Name: Lessons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lessons" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    "studentId" uuid NOT NULL
);


ALTER TABLE public."Lessons" OWNER TO postgres;

--
-- Name: Parents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Parents" (
    id uuid NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255),
    avatar character varying(255),
    "phoneNumber" text,
    email character varying(255),
    "loginId" character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT false,
    role public."enum_Parents_role" DEFAULT 'parent'::public."enum_Parents_role" NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Parents" OWNER TO postgres;

--
-- Name: Positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Positions" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public."Positions" OWNER TO postgres;

--
-- Name: Recruitors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Recruitors" (
    id uuid NOT NULL,
    avatar character varying(255),
    "loginId" character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255),
    "companyName" character varying(255),
    specialisation character varying(255),
    "phoneNumber" character varying(255),
    email character varying(255),
    bio text,
    role public."enum_Recruitors_role" DEFAULT 'recruitor'::public."enum_Recruitors_role" NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Recruitors" OWNER TO postgres;

--
-- Name: Sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sections" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public."Sections" OWNER TO postgres;

--
-- Name: SelectedStudents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SelectedStudents" (
    "StudentId" uuid NOT NULL,
    "RecruitorId" uuid NOT NULL
);


ALTER TABLE public."SelectedStudents" OWNER TO postgres;

--
-- Name: Semesters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Semesters" (
    id uuid NOT NULL,
    "semesterNumber" integer NOT NULL,
    "lessonId" uuid NOT NULL
);


ALTER TABLE public."Semesters" OWNER TO postgres;

--
-- Name: Skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Skills" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255) NOT NULL
);


ALTER TABLE public."Skills" OWNER TO postgres;

--
-- Name: Specialisations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Specialisations" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    "sectionId" uuid
);


ALTER TABLE public."Specialisations" OWNER TO postgres;

--
-- Name: StudentParents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StudentParents" (
    id uuid NOT NULL,
    "StudentId" uuid,
    "ParentId" uuid
);


ALTER TABLE public."StudentParents" OWNER TO postgres;

--
-- Name: Students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Students" (
    id uuid NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255),
    "loginId" character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    "groupId" uuid,
    role public."enum_Students_role" DEFAULT 'student'::public."enum_Students_role",
    avatar character varying(255),
    bio text,
    "phoneNumber" text,
    brithday text,
    images character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    videos character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    "isDeleted" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT false,
    cv character varying(255),
    jlpt character varying(255),
    jdu character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "desc" text,
    "isArchive" boolean DEFAULT false
);


ALTER TABLE public."Students" OWNER TO postgres;

--
-- Name: Teachers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Teachers" (
    id uuid NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255),
    "fatherName" character varying(255),
    university character varying(255),
    avatar character varying(255),
    "loginId" character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(255),
    specialisation character varying(255),
    section character varying(255),
    "position" character varying(255),
    "phoneNumber" character varying(255),
    role public."enum_Teachers_role" DEFAULT 'teacher'::public."enum_Teachers_role" NOT NULL,
    "isActive" boolean DEFAULT false,
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Teachers" OWNER TO postgres;

--
-- Name: Tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tokens" (
    id integer NOT NULL,
    "userId" uuid NOT NULL,
    token character varying(255) NOT NULL
);


ALTER TABLE public."Tokens" OWNER TO postgres;

--
-- Name: Tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Tokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Tokens_id_seq" OWNER TO postgres;

--
-- Name: Tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Tokens_id_seq" OWNED BY public."Tokens".id;


--
-- Name: UniversityPercentages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UniversityPercentages" (
    id uuid NOT NULL,
    "Attendee" integer DEFAULT 0 NOT NULL,
    "ItCourse" integer DEFAULT 0 NOT NULL,
    "JapanLanguage" integer DEFAULT 0 NOT NULL,
    "SannoUniversity" integer DEFAULT 0 NOT NULL,
    "UzSWLUniversity" integer DEFAULT 0 NOT NULL,
    "CoWork" integer DEFAULT 0 NOT NULL,
    "AllMarks" numeric(5,2) DEFAULT 0 NOT NULL,
    "studentId" uuid NOT NULL
);


ALTER TABLE public."UniversityPercentages" OWNER TO postgres;

--
-- Name: Tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tokens" ALTER COLUMN id SET DEFAULT nextval('public."Tokens_id_seq"'::regclass);


--
-- Data for Name: Credits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Credits" (id, "lessonName", university, credit) FROM stdin;
\.
COPY public."Credits" (id, "lessonName", university, credit) FROM '$$PATH$$/7287.dat';

--
-- Data for Name: Decans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Decans" (id, "firstName", "lastName", "loginId", password, email, role, avatar, "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Decans" (id, "firstName", "lastName", "loginId", password, email, role, avatar, "isDeleted", "createdAt", "updatedAt") FROM '$$PATH$$/7292.dat';

--
-- Data for Name: Groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Groups" (id, name, collection, year, "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Groups" (id, name, collection, year, "isDeleted", "createdAt", "updatedAt") FROM '$$PATH$$/7276.dat';

--
-- Data for Name: Infos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Infos" (id, "phoneNumber", "startTime", "endTime", location, "emailInfo") FROM stdin;
\.
COPY public."Infos" (id, "phoneNumber", "startTime", "endTime", location, "emailInfo") FROM '$$PATH$$/7291.dat';

--
-- Data for Name: ItQualificationResults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ItQualificationResults" (id, procent, "ItQualificationId", "skillId") FROM stdin;
\.
COPY public."ItQualificationResults" (id, procent, "ItQualificationId", "skillId") FROM '$$PATH$$/7286.dat';

--
-- Data for Name: ItQualifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ItQualifications" (id, description, "studentId") FROM stdin;
\.
COPY public."ItQualifications" (id, description, "studentId") FROM '$$PATH$$/7279.dat';

--
-- Data for Name: JapanLanguageTests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."JapanLanguageTests" (id, name, level, listening, reading, writing, sertificate, "studentId") FROM stdin;
\.
COPY public."JapanLanguageTests" (id, name, level, listening, reading, writing, sertificate, "studentId") FROM '$$PATH$$/7278.dat';

--
-- Data for Name: LessonResults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LessonResults" (id, status, "semesterId", "creditId") FROM stdin;
\.
COPY public."LessonResults" (id, status, "semesterId", "creditId") FROM '$$PATH$$/7288.dat';

--
-- Data for Name: Lessons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lessons" (id, name, "studentId") FROM stdin;
\.
COPY public."Lessons" (id, name, "studentId") FROM '$$PATH$$/7280.dat';

--
-- Data for Name: Parents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Parents" (id, "firstName", "lastName", avatar, "phoneNumber", email, "loginId", password, "isDeleted", "isActive", role, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Parents" (id, "firstName", "lastName", avatar, "phoneNumber", email, "loginId", password, "isDeleted", "isActive", role, "createdAt", "updatedAt") FROM '$$PATH$$/7296.dat';

--
-- Data for Name: Positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Positions" (id, name) FROM stdin;
\.
COPY public."Positions" (id, name) FROM '$$PATH$$/7298.dat';

--
-- Data for Name: Recruitors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Recruitors" (id, avatar, "loginId", password, "firstName", "lastName", "companyName", specialisation, "phoneNumber", email, bio, role, "isDeleted", "isActive", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Recruitors" (id, avatar, "loginId", password, "firstName", "lastName", "companyName", specialisation, "phoneNumber", email, bio, role, "isDeleted", "isActive", "createdAt", "updatedAt") FROM '$$PATH$$/7293.dat';

--
-- Data for Name: Sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sections" (id, name) FROM stdin;
\.
COPY public."Sections" (id, name) FROM '$$PATH$$/7283.dat';

--
-- Data for Name: SelectedStudents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SelectedStudents" ("StudentId", "RecruitorId") FROM stdin;
\.
COPY public."SelectedStudents" ("StudentId", "RecruitorId") FROM '$$PATH$$/7294.dat';

--
-- Data for Name: Semesters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Semesters" (id, "semesterNumber", "lessonId") FROM stdin;
\.
COPY public."Semesters" (id, "semesterNumber", "lessonId") FROM '$$PATH$$/7281.dat';

--
-- Data for Name: Skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Skills" (id, name, color) FROM stdin;
\.
COPY public."Skills" (id, name, color) FROM '$$PATH$$/7285.dat';

--
-- Data for Name: Specialisations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Specialisations" (id, name, "sectionId") FROM stdin;
\.
COPY public."Specialisations" (id, name, "sectionId") FROM '$$PATH$$/7284.dat';

--
-- Data for Name: StudentParents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StudentParents" (id, "StudentId", "ParentId") FROM stdin;
\.
COPY public."StudentParents" (id, "StudentId", "ParentId") FROM '$$PATH$$/7297.dat';

--
-- Data for Name: Students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Students" (id, "firstName", "lastName", "loginId", password, email, "groupId", role, avatar, bio, "phoneNumber", brithday, images, videos, "isDeleted", "isActive", cv, jlpt, jdu, "createdAt", "updatedAt", "desc", "isArchive") FROM stdin;
\.
COPY public."Students" (id, "firstName", "lastName", "loginId", password, email, "groupId", role, avatar, bio, "phoneNumber", brithday, images, videos, "isDeleted", "isActive", cv, jlpt, jdu, "createdAt", "updatedAt", "desc", "isArchive") FROM '$$PATH$$/7277.dat';

--
-- Data for Name: Teachers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Teachers" (id, "firstName", "lastName", "fatherName", university, avatar, "loginId", password, email, specialisation, section, "position", "phoneNumber", role, "isActive", "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Teachers" (id, "firstName", "lastName", "fatherName", university, avatar, "loginId", password, email, specialisation, section, "position", "phoneNumber", role, "isActive", "isDeleted", "createdAt", "updatedAt") FROM '$$PATH$$/7295.dat';

--
-- Data for Name: Tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tokens" (id, "userId", token) FROM stdin;
\.
COPY public."Tokens" (id, "userId", token) FROM '$$PATH$$/7290.dat';

--
-- Data for Name: UniversityPercentages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UniversityPercentages" (id, "Attendee", "ItCourse", "JapanLanguage", "SannoUniversity", "UzSWLUniversity", "CoWork", "AllMarks", "studentId") FROM stdin;
\.
COPY public."UniversityPercentages" (id, "Attendee", "ItCourse", "JapanLanguage", "SannoUniversity", "UzSWLUniversity", "CoWork", "AllMarks", "studentId") FROM '$$PATH$$/7282.dat';

--
-- Name: Tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Tokens_id_seq"', 4, true);


--
-- Name: Credits Credits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Credits"
    ADD CONSTRAINT "Credits_pkey" PRIMARY KEY (id);


--
-- Name: Decans Decans_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key" UNIQUE (email);


--
-- Name: Decans Decans_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key1" UNIQUE (email);


--
-- Name: Decans Decans_email_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key10" UNIQUE (email);


--
-- Name: Decans Decans_email_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key11" UNIQUE (email);


--
-- Name: Decans Decans_email_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key12" UNIQUE (email);


--
-- Name: Decans Decans_email_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key13" UNIQUE (email);


--
-- Name: Decans Decans_email_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key14" UNIQUE (email);


--
-- Name: Decans Decans_email_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key15" UNIQUE (email);


--
-- Name: Decans Decans_email_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key16" UNIQUE (email);


--
-- Name: Decans Decans_email_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key17" UNIQUE (email);


--
-- Name: Decans Decans_email_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key18" UNIQUE (email);


--
-- Name: Decans Decans_email_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key19" UNIQUE (email);


--
-- Name: Decans Decans_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key2" UNIQUE (email);


--
-- Name: Decans Decans_email_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key20" UNIQUE (email);


--
-- Name: Decans Decans_email_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key21" UNIQUE (email);


--
-- Name: Decans Decans_email_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key22" UNIQUE (email);


--
-- Name: Decans Decans_email_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key23" UNIQUE (email);


--
-- Name: Decans Decans_email_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key24" UNIQUE (email);


--
-- Name: Decans Decans_email_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key25" UNIQUE (email);


--
-- Name: Decans Decans_email_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key26" UNIQUE (email);


--
-- Name: Decans Decans_email_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key27" UNIQUE (email);


--
-- Name: Decans Decans_email_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key28" UNIQUE (email);


--
-- Name: Decans Decans_email_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key29" UNIQUE (email);


--
-- Name: Decans Decans_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key3" UNIQUE (email);


--
-- Name: Decans Decans_email_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key30" UNIQUE (email);


--
-- Name: Decans Decans_email_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key31" UNIQUE (email);


--
-- Name: Decans Decans_email_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key32" UNIQUE (email);


--
-- Name: Decans Decans_email_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key33" UNIQUE (email);


--
-- Name: Decans Decans_email_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key34" UNIQUE (email);


--
-- Name: Decans Decans_email_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key35" UNIQUE (email);


--
-- Name: Decans Decans_email_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key36" UNIQUE (email);


--
-- Name: Decans Decans_email_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key37" UNIQUE (email);


--
-- Name: Decans Decans_email_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key38" UNIQUE (email);


--
-- Name: Decans Decans_email_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key39" UNIQUE (email);


--
-- Name: Decans Decans_email_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key4" UNIQUE (email);


--
-- Name: Decans Decans_email_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key40" UNIQUE (email);


--
-- Name: Decans Decans_email_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key41" UNIQUE (email);


--
-- Name: Decans Decans_email_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key42" UNIQUE (email);


--
-- Name: Decans Decans_email_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key43" UNIQUE (email);


--
-- Name: Decans Decans_email_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key44" UNIQUE (email);


--
-- Name: Decans Decans_email_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key45" UNIQUE (email);


--
-- Name: Decans Decans_email_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key46" UNIQUE (email);


--
-- Name: Decans Decans_email_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key47" UNIQUE (email);


--
-- Name: Decans Decans_email_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key48" UNIQUE (email);


--
-- Name: Decans Decans_email_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key49" UNIQUE (email);


--
-- Name: Decans Decans_email_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key5" UNIQUE (email);


--
-- Name: Decans Decans_email_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key50" UNIQUE (email);


--
-- Name: Decans Decans_email_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key51" UNIQUE (email);


--
-- Name: Decans Decans_email_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key52" UNIQUE (email);


--
-- Name: Decans Decans_email_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key53" UNIQUE (email);


--
-- Name: Decans Decans_email_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key54" UNIQUE (email);


--
-- Name: Decans Decans_email_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key55" UNIQUE (email);


--
-- Name: Decans Decans_email_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key56" UNIQUE (email);


--
-- Name: Decans Decans_email_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key57" UNIQUE (email);


--
-- Name: Decans Decans_email_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key58" UNIQUE (email);


--
-- Name: Decans Decans_email_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key59" UNIQUE (email);


--
-- Name: Decans Decans_email_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key6" UNIQUE (email);


--
-- Name: Decans Decans_email_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key60" UNIQUE (email);


--
-- Name: Decans Decans_email_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key61" UNIQUE (email);


--
-- Name: Decans Decans_email_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key62" UNIQUE (email);


--
-- Name: Decans Decans_email_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key63" UNIQUE (email);


--
-- Name: Decans Decans_email_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key64" UNIQUE (email);


--
-- Name: Decans Decans_email_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key65" UNIQUE (email);


--
-- Name: Decans Decans_email_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key66" UNIQUE (email);


--
-- Name: Decans Decans_email_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key67" UNIQUE (email);


--
-- Name: Decans Decans_email_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key68" UNIQUE (email);


--
-- Name: Decans Decans_email_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key69" UNIQUE (email);


--
-- Name: Decans Decans_email_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key7" UNIQUE (email);


--
-- Name: Decans Decans_email_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key70" UNIQUE (email);


--
-- Name: Decans Decans_email_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key71" UNIQUE (email);


--
-- Name: Decans Decans_email_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key72" UNIQUE (email);


--
-- Name: Decans Decans_email_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key73" UNIQUE (email);


--
-- Name: Decans Decans_email_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key74" UNIQUE (email);


--
-- Name: Decans Decans_email_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key75" UNIQUE (email);


--
-- Name: Decans Decans_email_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key76" UNIQUE (email);


--
-- Name: Decans Decans_email_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key77" UNIQUE (email);


--
-- Name: Decans Decans_email_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key78" UNIQUE (email);


--
-- Name: Decans Decans_email_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key79" UNIQUE (email);


--
-- Name: Decans Decans_email_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key8" UNIQUE (email);


--
-- Name: Decans Decans_email_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key80" UNIQUE (email);


--
-- Name: Decans Decans_email_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key81" UNIQUE (email);


--
-- Name: Decans Decans_email_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key82" UNIQUE (email);


--
-- Name: Decans Decans_email_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key83" UNIQUE (email);


--
-- Name: Decans Decans_email_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key84" UNIQUE (email);


--
-- Name: Decans Decans_email_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key85" UNIQUE (email);


--
-- Name: Decans Decans_email_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key86" UNIQUE (email);


--
-- Name: Decans Decans_email_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key87" UNIQUE (email);


--
-- Name: Decans Decans_email_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key88" UNIQUE (email);


--
-- Name: Decans Decans_email_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key89" UNIQUE (email);


--
-- Name: Decans Decans_email_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key9" UNIQUE (email);


--
-- Name: Decans Decans_email_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key90" UNIQUE (email);


--
-- Name: Decans Decans_email_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key91" UNIQUE (email);


--
-- Name: Decans Decans_email_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key92" UNIQUE (email);


--
-- Name: Decans Decans_email_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key93" UNIQUE (email);


--
-- Name: Decans Decans_email_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key94" UNIQUE (email);


--
-- Name: Decans Decans_email_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key95" UNIQUE (email);


--
-- Name: Decans Decans_email_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_email_key96" UNIQUE (email);


--
-- Name: Decans Decans_loginId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key1" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key10" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key100" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key101" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key102" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key103" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key104" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key105" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key106" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key107" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key108" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key109" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key11" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key110" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key111" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key112" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key113" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key114" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key115" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key116" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key117" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key118" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key119" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key12" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key120" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key121" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key122" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key123" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key124" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key125" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key126" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key127" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key128" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key129" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key13" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key130" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key131" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key132" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key133" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key134" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key135" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key136" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key137" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key138" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key139" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key14" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key140" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key141" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key142" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key143" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key144" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key145" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key146" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key147" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key148" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key149" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key15" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key150" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key151" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key152" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key153" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key154" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key155" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key156" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key157" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key158" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key159" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key16" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key160" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key161" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key162" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key163" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key164" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key165" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key166" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key167" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key168" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key169" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key17" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key170" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key171" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key172" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key173" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key174" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key18" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key19" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key2" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key20" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key21" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key22" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key23" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key24" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key25" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key26" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key27" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key28" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key29" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key3" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key30" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key31" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key32" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key33" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key34" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key35" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key36" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key37" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key38" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key39" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key4" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key40" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key41" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key42" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key43" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key44" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key45" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key46" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key47" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key48" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key49" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key5" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key50" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key51" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key52" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key53" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key54" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key55" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key56" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key57" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key58" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key59" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key6" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key60" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key61" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key62" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key63" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key64" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key65" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key66" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key67" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key68" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key69" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key7" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key70" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key71" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key72" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key73" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key74" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key75" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key76" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key77" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key78" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key79" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key8" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key80" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key81" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key82" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key83" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key84" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key85" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key86" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key87" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key88" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key89" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key9" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key90" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key91" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key92" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key93" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key94" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key95" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key96" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key97" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key98" UNIQUE ("loginId");


--
-- Name: Decans Decans_loginId_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_loginId_key99" UNIQUE ("loginId");


--
-- Name: Decans Decans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Decans"
    ADD CONSTRAINT "Decans_pkey" PRIMARY KEY (id);


--
-- Name: Groups Groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Groups"
    ADD CONSTRAINT "Groups_pkey" PRIMARY KEY (id);


--
-- Name: Infos Infos_emailInfo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key1" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key10" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key100" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key101" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key102" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key103" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key104" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key105" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key106" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key107" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key108" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key109" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key11" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key110" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key111" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key112" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key113" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key114" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key115" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key116" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key117" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key118" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key119" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key12" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key120" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key121" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key122" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key123" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key124" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key125" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key126" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key127" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key128" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key129" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key13" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key130" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key131" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key132" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key133" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key134" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key135" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key136" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key137" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key138" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key139" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key14" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key140" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key141" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key142" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key143" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key144" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key145" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key146" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key147" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key148" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key149" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key15" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key150" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key151" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key152" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key153" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key154" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key155" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key156" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key157" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key158" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key159" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key16" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key160" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key161" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key162" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key163" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key164" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key165" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key166" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key167" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key168" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key169" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key17" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key18" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key19" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key2" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key20" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key21" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key22" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key23" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key24" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key25" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key26" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key27" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key28" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key29" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key3" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key30" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key31" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key32" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key33" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key34" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key35" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key36" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key37" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key38" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key39" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key4" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key40" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key41" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key42" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key43" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key44" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key45" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key46" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key47" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key48" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key49" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key5" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key50" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key51" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key52" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key53" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key54" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key55" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key56" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key57" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key58" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key59" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key6" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key60" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key61" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key62" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key63" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key64" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key65" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key66" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key67" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key68" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key69" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key7" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key70" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key71" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key72" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key73" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key74" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key75" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key76" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key77" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key78" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key79" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key8" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key80" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key81" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key82" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key83" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key84" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key85" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key86" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key87" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key88" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key89" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key9" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key90" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key91" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key92" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key93" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key94" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key95" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key96" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key97" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key98" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_emailInfo_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_emailInfo_key99" UNIQUE ("emailInfo");


--
-- Name: Infos Infos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Infos"
    ADD CONSTRAINT "Infos_pkey" PRIMARY KEY (id);


--
-- Name: ItQualificationResults ItQualificationResults_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ItQualificationResults"
    ADD CONSTRAINT "ItQualificationResults_pkey" PRIMARY KEY (id);


--
-- Name: ItQualifications ItQualifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ItQualifications"
    ADD CONSTRAINT "ItQualifications_pkey" PRIMARY KEY (id);


--
-- Name: JapanLanguageTests JapanLanguageTests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."JapanLanguageTests"
    ADD CONSTRAINT "JapanLanguageTests_pkey" PRIMARY KEY (id);


--
-- Name: LessonResults LessonResults_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LessonResults"
    ADD CONSTRAINT "LessonResults_pkey" PRIMARY KEY (id);


--
-- Name: Lessons Lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lessons"
    ADD CONSTRAINT "Lessons_pkey" PRIMARY KEY (id);


--
-- Name: Parents Parents_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key" UNIQUE (email);


--
-- Name: Parents Parents_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key1" UNIQUE (email);


--
-- Name: Parents Parents_email_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key10" UNIQUE (email);


--
-- Name: Parents Parents_email_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key11" UNIQUE (email);


--
-- Name: Parents Parents_email_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key12" UNIQUE (email);


--
-- Name: Parents Parents_email_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key13" UNIQUE (email);


--
-- Name: Parents Parents_email_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key14" UNIQUE (email);


--
-- Name: Parents Parents_email_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key15" UNIQUE (email);


--
-- Name: Parents Parents_email_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key16" UNIQUE (email);


--
-- Name: Parents Parents_email_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key17" UNIQUE (email);


--
-- Name: Parents Parents_email_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key18" UNIQUE (email);


--
-- Name: Parents Parents_email_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key19" UNIQUE (email);


--
-- Name: Parents Parents_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key2" UNIQUE (email);


--
-- Name: Parents Parents_email_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key20" UNIQUE (email);


--
-- Name: Parents Parents_email_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key21" UNIQUE (email);


--
-- Name: Parents Parents_email_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key22" UNIQUE (email);


--
-- Name: Parents Parents_email_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key23" UNIQUE (email);


--
-- Name: Parents Parents_email_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key24" UNIQUE (email);


--
-- Name: Parents Parents_email_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key25" UNIQUE (email);


--
-- Name: Parents Parents_email_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key26" UNIQUE (email);


--
-- Name: Parents Parents_email_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key27" UNIQUE (email);


--
-- Name: Parents Parents_email_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key28" UNIQUE (email);


--
-- Name: Parents Parents_email_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key29" UNIQUE (email);


--
-- Name: Parents Parents_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key3" UNIQUE (email);


--
-- Name: Parents Parents_email_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key30" UNIQUE (email);


--
-- Name: Parents Parents_email_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key31" UNIQUE (email);


--
-- Name: Parents Parents_email_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key32" UNIQUE (email);


--
-- Name: Parents Parents_email_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key33" UNIQUE (email);


--
-- Name: Parents Parents_email_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key34" UNIQUE (email);


--
-- Name: Parents Parents_email_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key35" UNIQUE (email);


--
-- Name: Parents Parents_email_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key36" UNIQUE (email);


--
-- Name: Parents Parents_email_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key37" UNIQUE (email);


--
-- Name: Parents Parents_email_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key38" UNIQUE (email);


--
-- Name: Parents Parents_email_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key39" UNIQUE (email);


--
-- Name: Parents Parents_email_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key4" UNIQUE (email);


--
-- Name: Parents Parents_email_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key40" UNIQUE (email);


--
-- Name: Parents Parents_email_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key41" UNIQUE (email);


--
-- Name: Parents Parents_email_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key42" UNIQUE (email);


--
-- Name: Parents Parents_email_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key43" UNIQUE (email);


--
-- Name: Parents Parents_email_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key44" UNIQUE (email);


--
-- Name: Parents Parents_email_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key45" UNIQUE (email);


--
-- Name: Parents Parents_email_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key46" UNIQUE (email);


--
-- Name: Parents Parents_email_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key47" UNIQUE (email);


--
-- Name: Parents Parents_email_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key48" UNIQUE (email);


--
-- Name: Parents Parents_email_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key49" UNIQUE (email);


--
-- Name: Parents Parents_email_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key5" UNIQUE (email);


--
-- Name: Parents Parents_email_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key50" UNIQUE (email);


--
-- Name: Parents Parents_email_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key51" UNIQUE (email);


--
-- Name: Parents Parents_email_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key52" UNIQUE (email);


--
-- Name: Parents Parents_email_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key53" UNIQUE (email);


--
-- Name: Parents Parents_email_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key54" UNIQUE (email);


--
-- Name: Parents Parents_email_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key55" UNIQUE (email);


--
-- Name: Parents Parents_email_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key56" UNIQUE (email);


--
-- Name: Parents Parents_email_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key57" UNIQUE (email);


--
-- Name: Parents Parents_email_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key58" UNIQUE (email);


--
-- Name: Parents Parents_email_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key59" UNIQUE (email);


--
-- Name: Parents Parents_email_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key6" UNIQUE (email);


--
-- Name: Parents Parents_email_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key60" UNIQUE (email);


--
-- Name: Parents Parents_email_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key61" UNIQUE (email);


--
-- Name: Parents Parents_email_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key62" UNIQUE (email);


--
-- Name: Parents Parents_email_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key63" UNIQUE (email);


--
-- Name: Parents Parents_email_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key64" UNIQUE (email);


--
-- Name: Parents Parents_email_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key65" UNIQUE (email);


--
-- Name: Parents Parents_email_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key66" UNIQUE (email);


--
-- Name: Parents Parents_email_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key67" UNIQUE (email);


--
-- Name: Parents Parents_email_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key68" UNIQUE (email);


--
-- Name: Parents Parents_email_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key69" UNIQUE (email);


--
-- Name: Parents Parents_email_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key7" UNIQUE (email);


--
-- Name: Parents Parents_email_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key70" UNIQUE (email);


--
-- Name: Parents Parents_email_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key71" UNIQUE (email);


--
-- Name: Parents Parents_email_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key72" UNIQUE (email);


--
-- Name: Parents Parents_email_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key73" UNIQUE (email);


--
-- Name: Parents Parents_email_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key74" UNIQUE (email);


--
-- Name: Parents Parents_email_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key75" UNIQUE (email);


--
-- Name: Parents Parents_email_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key76" UNIQUE (email);


--
-- Name: Parents Parents_email_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key77" UNIQUE (email);


--
-- Name: Parents Parents_email_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key78" UNIQUE (email);


--
-- Name: Parents Parents_email_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key79" UNIQUE (email);


--
-- Name: Parents Parents_email_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key8" UNIQUE (email);


--
-- Name: Parents Parents_email_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key80" UNIQUE (email);


--
-- Name: Parents Parents_email_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key81" UNIQUE (email);


--
-- Name: Parents Parents_email_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key82" UNIQUE (email);


--
-- Name: Parents Parents_email_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key83" UNIQUE (email);


--
-- Name: Parents Parents_email_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key84" UNIQUE (email);


--
-- Name: Parents Parents_email_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key85" UNIQUE (email);


--
-- Name: Parents Parents_email_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key86" UNIQUE (email);


--
-- Name: Parents Parents_email_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key87" UNIQUE (email);


--
-- Name: Parents Parents_email_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key88" UNIQUE (email);


--
-- Name: Parents Parents_email_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key89" UNIQUE (email);


--
-- Name: Parents Parents_email_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key9" UNIQUE (email);


--
-- Name: Parents Parents_email_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key90" UNIQUE (email);


--
-- Name: Parents Parents_email_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key91" UNIQUE (email);


--
-- Name: Parents Parents_email_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key92" UNIQUE (email);


--
-- Name: Parents Parents_email_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key93" UNIQUE (email);


--
-- Name: Parents Parents_email_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key94" UNIQUE (email);


--
-- Name: Parents Parents_email_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key95" UNIQUE (email);


--
-- Name: Parents Parents_email_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_email_key96" UNIQUE (email);


--
-- Name: Parents Parents_loginId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key1" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key10" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key100" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key101" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key102" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key103" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key104" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key105" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key106" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key107" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key108" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key109" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key11" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key110" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key111" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key112" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key113" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key114" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key115" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key116" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key117" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key118" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key119" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key12" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key120" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key121" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key122" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key123" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key124" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key125" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key126" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key127" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key128" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key129" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key13" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key130" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key131" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key132" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key133" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key134" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key135" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key136" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key137" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key138" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key139" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key14" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key140" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key141" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key142" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key143" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key144" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key145" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key146" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key147" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key148" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key149" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key15" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key150" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key151" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key152" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key153" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key154" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key155" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key156" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key157" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key158" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key159" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key16" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key160" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key161" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key162" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key163" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key164" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key165" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key166" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key167" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key168" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key169" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key17" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key170" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key171" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key172" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key173" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key174" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key18" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key19" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key2" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key20" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key21" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key22" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key23" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key24" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key25" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key26" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key27" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key28" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key29" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key3" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key30" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key31" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key32" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key33" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key34" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key35" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key36" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key37" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key38" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key39" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key4" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key40" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key41" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key42" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key43" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key44" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key45" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key46" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key47" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key48" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key49" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key5" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key50" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key51" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key52" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key53" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key54" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key55" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key56" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key57" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key58" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key59" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key6" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key60" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key61" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key62" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key63" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key64" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key65" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key66" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key67" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key68" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key69" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key7" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key70" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key71" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key72" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key73" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key74" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key75" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key76" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key77" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key78" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key79" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key8" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key80" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key81" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key82" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key83" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key84" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key85" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key86" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key87" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key88" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key89" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key9" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key90" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key91" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key92" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key93" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key94" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key95" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key96" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key97" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key98" UNIQUE ("loginId");


--
-- Name: Parents Parents_loginId_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_loginId_key99" UNIQUE ("loginId");


--
-- Name: Parents Parents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parents"
    ADD CONSTRAINT "Parents_pkey" PRIMARY KEY (id);


--
-- Name: Positions Positions_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key" UNIQUE (name);


--
-- Name: Positions Positions_name_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key1" UNIQUE (name);


--
-- Name: Positions Positions_name_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key10" UNIQUE (name);


--
-- Name: Positions Positions_name_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key100" UNIQUE (name);


--
-- Name: Positions Positions_name_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key101" UNIQUE (name);


--
-- Name: Positions Positions_name_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key102" UNIQUE (name);


--
-- Name: Positions Positions_name_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key103" UNIQUE (name);


--
-- Name: Positions Positions_name_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key104" UNIQUE (name);


--
-- Name: Positions Positions_name_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key105" UNIQUE (name);


--
-- Name: Positions Positions_name_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key106" UNIQUE (name);


--
-- Name: Positions Positions_name_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key107" UNIQUE (name);


--
-- Name: Positions Positions_name_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key108" UNIQUE (name);


--
-- Name: Positions Positions_name_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key109" UNIQUE (name);


--
-- Name: Positions Positions_name_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key11" UNIQUE (name);


--
-- Name: Positions Positions_name_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key110" UNIQUE (name);


--
-- Name: Positions Positions_name_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key111" UNIQUE (name);


--
-- Name: Positions Positions_name_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key112" UNIQUE (name);


--
-- Name: Positions Positions_name_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key113" UNIQUE (name);


--
-- Name: Positions Positions_name_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key114" UNIQUE (name);


--
-- Name: Positions Positions_name_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key115" UNIQUE (name);


--
-- Name: Positions Positions_name_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key116" UNIQUE (name);


--
-- Name: Positions Positions_name_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key117" UNIQUE (name);


--
-- Name: Positions Positions_name_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key118" UNIQUE (name);


--
-- Name: Positions Positions_name_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key119" UNIQUE (name);


--
-- Name: Positions Positions_name_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key12" UNIQUE (name);


--
-- Name: Positions Positions_name_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key120" UNIQUE (name);


--
-- Name: Positions Positions_name_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key121" UNIQUE (name);


--
-- Name: Positions Positions_name_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key122" UNIQUE (name);


--
-- Name: Positions Positions_name_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key123" UNIQUE (name);


--
-- Name: Positions Positions_name_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key124" UNIQUE (name);


--
-- Name: Positions Positions_name_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key125" UNIQUE (name);


--
-- Name: Positions Positions_name_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key126" UNIQUE (name);


--
-- Name: Positions Positions_name_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key127" UNIQUE (name);


--
-- Name: Positions Positions_name_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key128" UNIQUE (name);


--
-- Name: Positions Positions_name_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key129" UNIQUE (name);


--
-- Name: Positions Positions_name_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key13" UNIQUE (name);


--
-- Name: Positions Positions_name_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key130" UNIQUE (name);


--
-- Name: Positions Positions_name_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key131" UNIQUE (name);


--
-- Name: Positions Positions_name_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key132" UNIQUE (name);


--
-- Name: Positions Positions_name_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key133" UNIQUE (name);


--
-- Name: Positions Positions_name_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key134" UNIQUE (name);


--
-- Name: Positions Positions_name_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key135" UNIQUE (name);


--
-- Name: Positions Positions_name_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key136" UNIQUE (name);


--
-- Name: Positions Positions_name_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key137" UNIQUE (name);


--
-- Name: Positions Positions_name_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key138" UNIQUE (name);


--
-- Name: Positions Positions_name_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key139" UNIQUE (name);


--
-- Name: Positions Positions_name_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key14" UNIQUE (name);


--
-- Name: Positions Positions_name_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key140" UNIQUE (name);


--
-- Name: Positions Positions_name_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key141" UNIQUE (name);


--
-- Name: Positions Positions_name_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key142" UNIQUE (name);


--
-- Name: Positions Positions_name_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key143" UNIQUE (name);


--
-- Name: Positions Positions_name_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key144" UNIQUE (name);


--
-- Name: Positions Positions_name_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key145" UNIQUE (name);


--
-- Name: Positions Positions_name_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key146" UNIQUE (name);


--
-- Name: Positions Positions_name_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key147" UNIQUE (name);


--
-- Name: Positions Positions_name_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key148" UNIQUE (name);


--
-- Name: Positions Positions_name_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key149" UNIQUE (name);


--
-- Name: Positions Positions_name_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key15" UNIQUE (name);


--
-- Name: Positions Positions_name_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key150" UNIQUE (name);


--
-- Name: Positions Positions_name_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key151" UNIQUE (name);


--
-- Name: Positions Positions_name_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key152" UNIQUE (name);


--
-- Name: Positions Positions_name_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key153" UNIQUE (name);


--
-- Name: Positions Positions_name_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key154" UNIQUE (name);


--
-- Name: Positions Positions_name_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key155" UNIQUE (name);


--
-- Name: Positions Positions_name_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key156" UNIQUE (name);


--
-- Name: Positions Positions_name_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key157" UNIQUE (name);


--
-- Name: Positions Positions_name_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key158" UNIQUE (name);


--
-- Name: Positions Positions_name_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key159" UNIQUE (name);


--
-- Name: Positions Positions_name_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key16" UNIQUE (name);


--
-- Name: Positions Positions_name_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key160" UNIQUE (name);


--
-- Name: Positions Positions_name_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key161" UNIQUE (name);


--
-- Name: Positions Positions_name_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key162" UNIQUE (name);


--
-- Name: Positions Positions_name_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key163" UNIQUE (name);


--
-- Name: Positions Positions_name_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key164" UNIQUE (name);


--
-- Name: Positions Positions_name_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key165" UNIQUE (name);


--
-- Name: Positions Positions_name_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key166" UNIQUE (name);


--
-- Name: Positions Positions_name_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key167" UNIQUE (name);


--
-- Name: Positions Positions_name_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key168" UNIQUE (name);


--
-- Name: Positions Positions_name_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key169" UNIQUE (name);


--
-- Name: Positions Positions_name_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key17" UNIQUE (name);


--
-- Name: Positions Positions_name_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key170" UNIQUE (name);


--
-- Name: Positions Positions_name_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key171" UNIQUE (name);


--
-- Name: Positions Positions_name_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key172" UNIQUE (name);


--
-- Name: Positions Positions_name_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key173" UNIQUE (name);


--
-- Name: Positions Positions_name_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key174" UNIQUE (name);


--
-- Name: Positions Positions_name_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key18" UNIQUE (name);


--
-- Name: Positions Positions_name_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key19" UNIQUE (name);


--
-- Name: Positions Positions_name_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key2" UNIQUE (name);


--
-- Name: Positions Positions_name_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key20" UNIQUE (name);


--
-- Name: Positions Positions_name_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key21" UNIQUE (name);


--
-- Name: Positions Positions_name_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key22" UNIQUE (name);


--
-- Name: Positions Positions_name_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key23" UNIQUE (name);


--
-- Name: Positions Positions_name_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key24" UNIQUE (name);


--
-- Name: Positions Positions_name_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key25" UNIQUE (name);


--
-- Name: Positions Positions_name_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key26" UNIQUE (name);


--
-- Name: Positions Positions_name_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key27" UNIQUE (name);


--
-- Name: Positions Positions_name_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key28" UNIQUE (name);


--
-- Name: Positions Positions_name_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key29" UNIQUE (name);


--
-- Name: Positions Positions_name_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key3" UNIQUE (name);


--
-- Name: Positions Positions_name_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key30" UNIQUE (name);


--
-- Name: Positions Positions_name_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key31" UNIQUE (name);


--
-- Name: Positions Positions_name_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key32" UNIQUE (name);


--
-- Name: Positions Positions_name_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key33" UNIQUE (name);


--
-- Name: Positions Positions_name_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key34" UNIQUE (name);


--
-- Name: Positions Positions_name_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key35" UNIQUE (name);


--
-- Name: Positions Positions_name_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key36" UNIQUE (name);


--
-- Name: Positions Positions_name_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key37" UNIQUE (name);


--
-- Name: Positions Positions_name_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key38" UNIQUE (name);


--
-- Name: Positions Positions_name_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key39" UNIQUE (name);


--
-- Name: Positions Positions_name_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key4" UNIQUE (name);


--
-- Name: Positions Positions_name_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key40" UNIQUE (name);


--
-- Name: Positions Positions_name_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key41" UNIQUE (name);


--
-- Name: Positions Positions_name_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key42" UNIQUE (name);


--
-- Name: Positions Positions_name_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key43" UNIQUE (name);


--
-- Name: Positions Positions_name_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key44" UNIQUE (name);


--
-- Name: Positions Positions_name_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key45" UNIQUE (name);


--
-- Name: Positions Positions_name_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key46" UNIQUE (name);


--
-- Name: Positions Positions_name_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key47" UNIQUE (name);


--
-- Name: Positions Positions_name_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key48" UNIQUE (name);


--
-- Name: Positions Positions_name_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key49" UNIQUE (name);


--
-- Name: Positions Positions_name_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key5" UNIQUE (name);


--
-- Name: Positions Positions_name_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key50" UNIQUE (name);


--
-- Name: Positions Positions_name_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key51" UNIQUE (name);


--
-- Name: Positions Positions_name_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key52" UNIQUE (name);


--
-- Name: Positions Positions_name_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key53" UNIQUE (name);


--
-- Name: Positions Positions_name_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key54" UNIQUE (name);


--
-- Name: Positions Positions_name_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key55" UNIQUE (name);


--
-- Name: Positions Positions_name_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key56" UNIQUE (name);


--
-- Name: Positions Positions_name_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key57" UNIQUE (name);


--
-- Name: Positions Positions_name_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key58" UNIQUE (name);


--
-- Name: Positions Positions_name_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key59" UNIQUE (name);


--
-- Name: Positions Positions_name_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key6" UNIQUE (name);


--
-- Name: Positions Positions_name_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key60" UNIQUE (name);


--
-- Name: Positions Positions_name_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key61" UNIQUE (name);


--
-- Name: Positions Positions_name_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key62" UNIQUE (name);


--
-- Name: Positions Positions_name_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key63" UNIQUE (name);


--
-- Name: Positions Positions_name_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key64" UNIQUE (name);


--
-- Name: Positions Positions_name_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key65" UNIQUE (name);


--
-- Name: Positions Positions_name_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key66" UNIQUE (name);


--
-- Name: Positions Positions_name_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key67" UNIQUE (name);


--
-- Name: Positions Positions_name_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key68" UNIQUE (name);


--
-- Name: Positions Positions_name_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key69" UNIQUE (name);


--
-- Name: Positions Positions_name_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key7" UNIQUE (name);


--
-- Name: Positions Positions_name_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key70" UNIQUE (name);


--
-- Name: Positions Positions_name_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key71" UNIQUE (name);


--
-- Name: Positions Positions_name_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key72" UNIQUE (name);


--
-- Name: Positions Positions_name_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key73" UNIQUE (name);


--
-- Name: Positions Positions_name_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key74" UNIQUE (name);


--
-- Name: Positions Positions_name_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key75" UNIQUE (name);


--
-- Name: Positions Positions_name_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key76" UNIQUE (name);


--
-- Name: Positions Positions_name_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key77" UNIQUE (name);


--
-- Name: Positions Positions_name_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key78" UNIQUE (name);


--
-- Name: Positions Positions_name_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key79" UNIQUE (name);


--
-- Name: Positions Positions_name_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key8" UNIQUE (name);


--
-- Name: Positions Positions_name_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key80" UNIQUE (name);


--
-- Name: Positions Positions_name_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key81" UNIQUE (name);


--
-- Name: Positions Positions_name_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key82" UNIQUE (name);


--
-- Name: Positions Positions_name_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key83" UNIQUE (name);


--
-- Name: Positions Positions_name_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key84" UNIQUE (name);


--
-- Name: Positions Positions_name_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key85" UNIQUE (name);


--
-- Name: Positions Positions_name_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key86" UNIQUE (name);


--
-- Name: Positions Positions_name_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key87" UNIQUE (name);


--
-- Name: Positions Positions_name_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key88" UNIQUE (name);


--
-- Name: Positions Positions_name_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key89" UNIQUE (name);


--
-- Name: Positions Positions_name_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key9" UNIQUE (name);


--
-- Name: Positions Positions_name_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key90" UNIQUE (name);


--
-- Name: Positions Positions_name_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key91" UNIQUE (name);


--
-- Name: Positions Positions_name_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key92" UNIQUE (name);


--
-- Name: Positions Positions_name_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key93" UNIQUE (name);


--
-- Name: Positions Positions_name_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key94" UNIQUE (name);


--
-- Name: Positions Positions_name_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key95" UNIQUE (name);


--
-- Name: Positions Positions_name_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key96" UNIQUE (name);


--
-- Name: Positions Positions_name_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key97" UNIQUE (name);


--
-- Name: Positions Positions_name_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key98" UNIQUE (name);


--
-- Name: Positions Positions_name_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_name_key99" UNIQUE (name);


--
-- Name: Positions Positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Positions"
    ADD CONSTRAINT "Positions_pkey" PRIMARY KEY (id);


--
-- Name: Recruitors Recruitors_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key1" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key10" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key11" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key12" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key13" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key14" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key15" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key16" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key17" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key18" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key19" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key2" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key20" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key21" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key22" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key23" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key24" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key25" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key26" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key27" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key28" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key29" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key3" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key30" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key31" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key32" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key33" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key34" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key35" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key36" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key37" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key38" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key39" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key4" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key40" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key41" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key42" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key43" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key44" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key45" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key46" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key47" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key48" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key49" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key5" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key50" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key51" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key52" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key53" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key54" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key55" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key56" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key57" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key58" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key59" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key6" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key60" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key61" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key62" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key63" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key64" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key65" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key66" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key67" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key68" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key69" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key7" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key70" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key71" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key72" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key73" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key74" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key75" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key76" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key77" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key78" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key79" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key8" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key80" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key81" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key82" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key83" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key84" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key85" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key86" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key87" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key88" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key89" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key9" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key90" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key91" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key92" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key93" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key94" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key95" UNIQUE (email);


--
-- Name: Recruitors Recruitors_email_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_email_key96" UNIQUE (email);


--
-- Name: Recruitors Recruitors_loginId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key1" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key10" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key100" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key101" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key102" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key103" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key104" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key105" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key106" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key107" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key108" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key109" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key11" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key110" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key111" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key112" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key113" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key114" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key115" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key116" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key117" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key118" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key119" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key12" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key120" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key121" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key122" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key123" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key124" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key125" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key126" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key127" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key128" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key129" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key13" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key130" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key131" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key132" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key133" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key134" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key135" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key136" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key137" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key138" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key139" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key14" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key140" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key141" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key142" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key143" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key144" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key145" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key146" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key147" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key148" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key149" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key15" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key150" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key151" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key152" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key153" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key154" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key155" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key156" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key157" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key158" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key159" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key16" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key160" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key161" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key162" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key163" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key164" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key165" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key166" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key167" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key168" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key169" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key17" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key170" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key171" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key172" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key173" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key174" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key18" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key19" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key2" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key20" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key21" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key22" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key23" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key24" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key25" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key26" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key27" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key28" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key29" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key3" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key30" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key31" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key32" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key33" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key34" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key35" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key36" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key37" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key38" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key39" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key4" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key40" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key41" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key42" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key43" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key44" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key45" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key46" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key47" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key48" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key49" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key5" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key50" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key51" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key52" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key53" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key54" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key55" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key56" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key57" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key58" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key59" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key6" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key60" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key61" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key62" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key63" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key64" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key65" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key66" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key67" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key68" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key69" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key7" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key70" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key71" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key72" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key73" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key74" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key75" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key76" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key77" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key78" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key79" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key8" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key80" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key81" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key82" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key83" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key84" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key85" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key86" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key87" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key88" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key89" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key9" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key90" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key91" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key92" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key93" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key94" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key95" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key96" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key97" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key98" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_loginId_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_loginId_key99" UNIQUE ("loginId");


--
-- Name: Recruitors Recruitors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recruitors"
    ADD CONSTRAINT "Recruitors_pkey" PRIMARY KEY (id);


--
-- Name: Sections Sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sections"
    ADD CONSTRAINT "Sections_pkey" PRIMARY KEY (id);


--
-- Name: SelectedStudents SelectedStudents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SelectedStudents"
    ADD CONSTRAINT "SelectedStudents_pkey" PRIMARY KEY ("StudentId", "RecruitorId");


--
-- Name: Semesters Semesters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Semesters"
    ADD CONSTRAINT "Semesters_pkey" PRIMARY KEY (id);


--
-- Name: Skills Skills_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key" UNIQUE (name);


--
-- Name: Skills Skills_name_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key1" UNIQUE (name);


--
-- Name: Skills Skills_name_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key10" UNIQUE (name);


--
-- Name: Skills Skills_name_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key100" UNIQUE (name);


--
-- Name: Skills Skills_name_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key101" UNIQUE (name);


--
-- Name: Skills Skills_name_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key102" UNIQUE (name);


--
-- Name: Skills Skills_name_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key103" UNIQUE (name);


--
-- Name: Skills Skills_name_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key104" UNIQUE (name);


--
-- Name: Skills Skills_name_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key105" UNIQUE (name);


--
-- Name: Skills Skills_name_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key106" UNIQUE (name);


--
-- Name: Skills Skills_name_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key107" UNIQUE (name);


--
-- Name: Skills Skills_name_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key108" UNIQUE (name);


--
-- Name: Skills Skills_name_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key109" UNIQUE (name);


--
-- Name: Skills Skills_name_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key11" UNIQUE (name);


--
-- Name: Skills Skills_name_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key110" UNIQUE (name);


--
-- Name: Skills Skills_name_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key111" UNIQUE (name);


--
-- Name: Skills Skills_name_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key112" UNIQUE (name);


--
-- Name: Skills Skills_name_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key113" UNIQUE (name);


--
-- Name: Skills Skills_name_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key114" UNIQUE (name);


--
-- Name: Skills Skills_name_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key115" UNIQUE (name);


--
-- Name: Skills Skills_name_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key116" UNIQUE (name);


--
-- Name: Skills Skills_name_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key117" UNIQUE (name);


--
-- Name: Skills Skills_name_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key118" UNIQUE (name);


--
-- Name: Skills Skills_name_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key119" UNIQUE (name);


--
-- Name: Skills Skills_name_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key12" UNIQUE (name);


--
-- Name: Skills Skills_name_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key120" UNIQUE (name);


--
-- Name: Skills Skills_name_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key121" UNIQUE (name);


--
-- Name: Skills Skills_name_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key122" UNIQUE (name);


--
-- Name: Skills Skills_name_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key123" UNIQUE (name);


--
-- Name: Skills Skills_name_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key124" UNIQUE (name);


--
-- Name: Skills Skills_name_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key125" UNIQUE (name);


--
-- Name: Skills Skills_name_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key126" UNIQUE (name);


--
-- Name: Skills Skills_name_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key127" UNIQUE (name);


--
-- Name: Skills Skills_name_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key128" UNIQUE (name);


--
-- Name: Skills Skills_name_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key129" UNIQUE (name);


--
-- Name: Skills Skills_name_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key13" UNIQUE (name);


--
-- Name: Skills Skills_name_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key130" UNIQUE (name);


--
-- Name: Skills Skills_name_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key131" UNIQUE (name);


--
-- Name: Skills Skills_name_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key132" UNIQUE (name);


--
-- Name: Skills Skills_name_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key133" UNIQUE (name);


--
-- Name: Skills Skills_name_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key134" UNIQUE (name);


--
-- Name: Skills Skills_name_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key135" UNIQUE (name);


--
-- Name: Skills Skills_name_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key136" UNIQUE (name);


--
-- Name: Skills Skills_name_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key137" UNIQUE (name);


--
-- Name: Skills Skills_name_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key138" UNIQUE (name);


--
-- Name: Skills Skills_name_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key139" UNIQUE (name);


--
-- Name: Skills Skills_name_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key14" UNIQUE (name);


--
-- Name: Skills Skills_name_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key140" UNIQUE (name);


--
-- Name: Skills Skills_name_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key141" UNIQUE (name);


--
-- Name: Skills Skills_name_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key142" UNIQUE (name);


--
-- Name: Skills Skills_name_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key143" UNIQUE (name);


--
-- Name: Skills Skills_name_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key144" UNIQUE (name);


--
-- Name: Skills Skills_name_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key145" UNIQUE (name);


--
-- Name: Skills Skills_name_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key146" UNIQUE (name);


--
-- Name: Skills Skills_name_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key147" UNIQUE (name);


--
-- Name: Skills Skills_name_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key148" UNIQUE (name);


--
-- Name: Skills Skills_name_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key149" UNIQUE (name);


--
-- Name: Skills Skills_name_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key15" UNIQUE (name);


--
-- Name: Skills Skills_name_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key150" UNIQUE (name);


--
-- Name: Skills Skills_name_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key151" UNIQUE (name);


--
-- Name: Skills Skills_name_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key152" UNIQUE (name);


--
-- Name: Skills Skills_name_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key153" UNIQUE (name);


--
-- Name: Skills Skills_name_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key154" UNIQUE (name);


--
-- Name: Skills Skills_name_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key155" UNIQUE (name);


--
-- Name: Skills Skills_name_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key156" UNIQUE (name);


--
-- Name: Skills Skills_name_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key157" UNIQUE (name);


--
-- Name: Skills Skills_name_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key158" UNIQUE (name);


--
-- Name: Skills Skills_name_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key159" UNIQUE (name);


--
-- Name: Skills Skills_name_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key16" UNIQUE (name);


--
-- Name: Skills Skills_name_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key160" UNIQUE (name);


--
-- Name: Skills Skills_name_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key161" UNIQUE (name);


--
-- Name: Skills Skills_name_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key162" UNIQUE (name);


--
-- Name: Skills Skills_name_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key163" UNIQUE (name);


--
-- Name: Skills Skills_name_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key164" UNIQUE (name);


--
-- Name: Skills Skills_name_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key165" UNIQUE (name);


--
-- Name: Skills Skills_name_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key166" UNIQUE (name);


--
-- Name: Skills Skills_name_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key167" UNIQUE (name);


--
-- Name: Skills Skills_name_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key168" UNIQUE (name);


--
-- Name: Skills Skills_name_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key169" UNIQUE (name);


--
-- Name: Skills Skills_name_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key17" UNIQUE (name);


--
-- Name: Skills Skills_name_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key170" UNIQUE (name);


--
-- Name: Skills Skills_name_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key171" UNIQUE (name);


--
-- Name: Skills Skills_name_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key172" UNIQUE (name);


--
-- Name: Skills Skills_name_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key173" UNIQUE (name);


--
-- Name: Skills Skills_name_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key174" UNIQUE (name);


--
-- Name: Skills Skills_name_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key18" UNIQUE (name);


--
-- Name: Skills Skills_name_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key19" UNIQUE (name);


--
-- Name: Skills Skills_name_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key2" UNIQUE (name);


--
-- Name: Skills Skills_name_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key20" UNIQUE (name);


--
-- Name: Skills Skills_name_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key21" UNIQUE (name);


--
-- Name: Skills Skills_name_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key22" UNIQUE (name);


--
-- Name: Skills Skills_name_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key23" UNIQUE (name);


--
-- Name: Skills Skills_name_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key24" UNIQUE (name);


--
-- Name: Skills Skills_name_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key25" UNIQUE (name);


--
-- Name: Skills Skills_name_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key26" UNIQUE (name);


--
-- Name: Skills Skills_name_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key27" UNIQUE (name);


--
-- Name: Skills Skills_name_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key28" UNIQUE (name);


--
-- Name: Skills Skills_name_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key29" UNIQUE (name);


--
-- Name: Skills Skills_name_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key3" UNIQUE (name);


--
-- Name: Skills Skills_name_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key30" UNIQUE (name);


--
-- Name: Skills Skills_name_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key31" UNIQUE (name);


--
-- Name: Skills Skills_name_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key32" UNIQUE (name);


--
-- Name: Skills Skills_name_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key33" UNIQUE (name);


--
-- Name: Skills Skills_name_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key34" UNIQUE (name);


--
-- Name: Skills Skills_name_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key35" UNIQUE (name);


--
-- Name: Skills Skills_name_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key36" UNIQUE (name);


--
-- Name: Skills Skills_name_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key37" UNIQUE (name);


--
-- Name: Skills Skills_name_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key38" UNIQUE (name);


--
-- Name: Skills Skills_name_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key39" UNIQUE (name);


--
-- Name: Skills Skills_name_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key4" UNIQUE (name);


--
-- Name: Skills Skills_name_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key40" UNIQUE (name);


--
-- Name: Skills Skills_name_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key41" UNIQUE (name);


--
-- Name: Skills Skills_name_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key42" UNIQUE (name);


--
-- Name: Skills Skills_name_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key43" UNIQUE (name);


--
-- Name: Skills Skills_name_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key44" UNIQUE (name);


--
-- Name: Skills Skills_name_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key45" UNIQUE (name);


--
-- Name: Skills Skills_name_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key46" UNIQUE (name);


--
-- Name: Skills Skills_name_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key47" UNIQUE (name);


--
-- Name: Skills Skills_name_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key48" UNIQUE (name);


--
-- Name: Skills Skills_name_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key49" UNIQUE (name);


--
-- Name: Skills Skills_name_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key5" UNIQUE (name);


--
-- Name: Skills Skills_name_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key50" UNIQUE (name);


--
-- Name: Skills Skills_name_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key51" UNIQUE (name);


--
-- Name: Skills Skills_name_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key52" UNIQUE (name);


--
-- Name: Skills Skills_name_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key53" UNIQUE (name);


--
-- Name: Skills Skills_name_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key54" UNIQUE (name);


--
-- Name: Skills Skills_name_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key55" UNIQUE (name);


--
-- Name: Skills Skills_name_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key56" UNIQUE (name);


--
-- Name: Skills Skills_name_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key57" UNIQUE (name);


--
-- Name: Skills Skills_name_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key58" UNIQUE (name);


--
-- Name: Skills Skills_name_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key59" UNIQUE (name);


--
-- Name: Skills Skills_name_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key6" UNIQUE (name);


--
-- Name: Skills Skills_name_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key60" UNIQUE (name);


--
-- Name: Skills Skills_name_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key61" UNIQUE (name);


--
-- Name: Skills Skills_name_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key62" UNIQUE (name);


--
-- Name: Skills Skills_name_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key63" UNIQUE (name);


--
-- Name: Skills Skills_name_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key64" UNIQUE (name);


--
-- Name: Skills Skills_name_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key65" UNIQUE (name);


--
-- Name: Skills Skills_name_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key66" UNIQUE (name);


--
-- Name: Skills Skills_name_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key67" UNIQUE (name);


--
-- Name: Skills Skills_name_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key68" UNIQUE (name);


--
-- Name: Skills Skills_name_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key69" UNIQUE (name);


--
-- Name: Skills Skills_name_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key7" UNIQUE (name);


--
-- Name: Skills Skills_name_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key70" UNIQUE (name);


--
-- Name: Skills Skills_name_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key71" UNIQUE (name);


--
-- Name: Skills Skills_name_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key72" UNIQUE (name);


--
-- Name: Skills Skills_name_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key73" UNIQUE (name);


--
-- Name: Skills Skills_name_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key74" UNIQUE (name);


--
-- Name: Skills Skills_name_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key75" UNIQUE (name);


--
-- Name: Skills Skills_name_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key76" UNIQUE (name);


--
-- Name: Skills Skills_name_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key77" UNIQUE (name);


--
-- Name: Skills Skills_name_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key78" UNIQUE (name);


--
-- Name: Skills Skills_name_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key79" UNIQUE (name);


--
-- Name: Skills Skills_name_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key8" UNIQUE (name);


--
-- Name: Skills Skills_name_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key80" UNIQUE (name);


--
-- Name: Skills Skills_name_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key81" UNIQUE (name);


--
-- Name: Skills Skills_name_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key82" UNIQUE (name);


--
-- Name: Skills Skills_name_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key83" UNIQUE (name);


--
-- Name: Skills Skills_name_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key84" UNIQUE (name);


--
-- Name: Skills Skills_name_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key85" UNIQUE (name);


--
-- Name: Skills Skills_name_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key86" UNIQUE (name);


--
-- Name: Skills Skills_name_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key87" UNIQUE (name);


--
-- Name: Skills Skills_name_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key88" UNIQUE (name);


--
-- Name: Skills Skills_name_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key89" UNIQUE (name);


--
-- Name: Skills Skills_name_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key9" UNIQUE (name);


--
-- Name: Skills Skills_name_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key90" UNIQUE (name);


--
-- Name: Skills Skills_name_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key91" UNIQUE (name);


--
-- Name: Skills Skills_name_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key92" UNIQUE (name);


--
-- Name: Skills Skills_name_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key93" UNIQUE (name);


--
-- Name: Skills Skills_name_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key94" UNIQUE (name);


--
-- Name: Skills Skills_name_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key95" UNIQUE (name);


--
-- Name: Skills Skills_name_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key96" UNIQUE (name);


--
-- Name: Skills Skills_name_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key97" UNIQUE (name);


--
-- Name: Skills Skills_name_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key98" UNIQUE (name);


--
-- Name: Skills Skills_name_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_name_key99" UNIQUE (name);


--
-- Name: Skills Skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "Skills_pkey" PRIMARY KEY (id);


--
-- Name: Specialisations Specialisations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialisations"
    ADD CONSTRAINT "Specialisations_pkey" PRIMARY KEY (id);


--
-- Name: StudentParents StudentParents_StudentId_ParentId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudentParents"
    ADD CONSTRAINT "StudentParents_StudentId_ParentId_key" UNIQUE ("StudentId", "ParentId");


--
-- Name: StudentParents StudentParents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudentParents"
    ADD CONSTRAINT "StudentParents_pkey" PRIMARY KEY (id);


--
-- Name: Students Students_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key" UNIQUE (email);


--
-- Name: Students Students_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key1" UNIQUE (email);


--
-- Name: Students Students_email_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key10" UNIQUE (email);


--
-- Name: Students Students_email_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key11" UNIQUE (email);


--
-- Name: Students Students_email_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key12" UNIQUE (email);


--
-- Name: Students Students_email_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key13" UNIQUE (email);


--
-- Name: Students Students_email_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key14" UNIQUE (email);


--
-- Name: Students Students_email_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key15" UNIQUE (email);


--
-- Name: Students Students_email_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key16" UNIQUE (email);


--
-- Name: Students Students_email_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key17" UNIQUE (email);


--
-- Name: Students Students_email_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key18" UNIQUE (email);


--
-- Name: Students Students_email_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key19" UNIQUE (email);


--
-- Name: Students Students_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key2" UNIQUE (email);


--
-- Name: Students Students_email_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key20" UNIQUE (email);


--
-- Name: Students Students_email_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key21" UNIQUE (email);


--
-- Name: Students Students_email_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key22" UNIQUE (email);


--
-- Name: Students Students_email_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key23" UNIQUE (email);


--
-- Name: Students Students_email_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key24" UNIQUE (email);


--
-- Name: Students Students_email_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key25" UNIQUE (email);


--
-- Name: Students Students_email_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key26" UNIQUE (email);


--
-- Name: Students Students_email_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key27" UNIQUE (email);


--
-- Name: Students Students_email_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key28" UNIQUE (email);


--
-- Name: Students Students_email_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key29" UNIQUE (email);


--
-- Name: Students Students_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key3" UNIQUE (email);


--
-- Name: Students Students_email_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key30" UNIQUE (email);


--
-- Name: Students Students_email_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key31" UNIQUE (email);


--
-- Name: Students Students_email_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key32" UNIQUE (email);


--
-- Name: Students Students_email_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key33" UNIQUE (email);


--
-- Name: Students Students_email_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key34" UNIQUE (email);


--
-- Name: Students Students_email_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key35" UNIQUE (email);


--
-- Name: Students Students_email_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key36" UNIQUE (email);


--
-- Name: Students Students_email_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key37" UNIQUE (email);


--
-- Name: Students Students_email_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key38" UNIQUE (email);


--
-- Name: Students Students_email_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key39" UNIQUE (email);


--
-- Name: Students Students_email_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key4" UNIQUE (email);


--
-- Name: Students Students_email_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key40" UNIQUE (email);


--
-- Name: Students Students_email_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key41" UNIQUE (email);


--
-- Name: Students Students_email_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key42" UNIQUE (email);


--
-- Name: Students Students_email_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key43" UNIQUE (email);


--
-- Name: Students Students_email_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key44" UNIQUE (email);


--
-- Name: Students Students_email_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key45" UNIQUE (email);


--
-- Name: Students Students_email_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key46" UNIQUE (email);


--
-- Name: Students Students_email_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key47" UNIQUE (email);


--
-- Name: Students Students_email_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key48" UNIQUE (email);


--
-- Name: Students Students_email_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key49" UNIQUE (email);


--
-- Name: Students Students_email_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key5" UNIQUE (email);


--
-- Name: Students Students_email_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key50" UNIQUE (email);


--
-- Name: Students Students_email_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key51" UNIQUE (email);


--
-- Name: Students Students_email_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key52" UNIQUE (email);


--
-- Name: Students Students_email_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key53" UNIQUE (email);


--
-- Name: Students Students_email_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key54" UNIQUE (email);


--
-- Name: Students Students_email_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key55" UNIQUE (email);


--
-- Name: Students Students_email_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key56" UNIQUE (email);


--
-- Name: Students Students_email_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key57" UNIQUE (email);


--
-- Name: Students Students_email_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key58" UNIQUE (email);


--
-- Name: Students Students_email_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key59" UNIQUE (email);


--
-- Name: Students Students_email_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key6" UNIQUE (email);


--
-- Name: Students Students_email_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key60" UNIQUE (email);


--
-- Name: Students Students_email_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key61" UNIQUE (email);


--
-- Name: Students Students_email_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key62" UNIQUE (email);


--
-- Name: Students Students_email_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key63" UNIQUE (email);


--
-- Name: Students Students_email_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key64" UNIQUE (email);


--
-- Name: Students Students_email_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key65" UNIQUE (email);


--
-- Name: Students Students_email_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key66" UNIQUE (email);


--
-- Name: Students Students_email_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key67" UNIQUE (email);


--
-- Name: Students Students_email_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key68" UNIQUE (email);


--
-- Name: Students Students_email_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key69" UNIQUE (email);


--
-- Name: Students Students_email_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key7" UNIQUE (email);


--
-- Name: Students Students_email_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key70" UNIQUE (email);


--
-- Name: Students Students_email_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key71" UNIQUE (email);


--
-- Name: Students Students_email_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key72" UNIQUE (email);


--
-- Name: Students Students_email_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key73" UNIQUE (email);


--
-- Name: Students Students_email_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key74" UNIQUE (email);


--
-- Name: Students Students_email_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key75" UNIQUE (email);


--
-- Name: Students Students_email_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key76" UNIQUE (email);


--
-- Name: Students Students_email_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key77" UNIQUE (email);


--
-- Name: Students Students_email_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key78" UNIQUE (email);


--
-- Name: Students Students_email_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key79" UNIQUE (email);


--
-- Name: Students Students_email_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key8" UNIQUE (email);


--
-- Name: Students Students_email_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key80" UNIQUE (email);


--
-- Name: Students Students_email_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key81" UNIQUE (email);


--
-- Name: Students Students_email_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key82" UNIQUE (email);


--
-- Name: Students Students_email_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key83" UNIQUE (email);


--
-- Name: Students Students_email_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key84" UNIQUE (email);


--
-- Name: Students Students_email_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key85" UNIQUE (email);


--
-- Name: Students Students_email_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key86" UNIQUE (email);


--
-- Name: Students Students_email_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key87" UNIQUE (email);


--
-- Name: Students Students_email_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key88" UNIQUE (email);


--
-- Name: Students Students_email_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key89" UNIQUE (email);


--
-- Name: Students Students_email_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key9" UNIQUE (email);


--
-- Name: Students Students_email_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key90" UNIQUE (email);


--
-- Name: Students Students_email_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key91" UNIQUE (email);


--
-- Name: Students Students_email_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key92" UNIQUE (email);


--
-- Name: Students Students_email_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key93" UNIQUE (email);


--
-- Name: Students Students_email_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key94" UNIQUE (email);


--
-- Name: Students Students_email_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key95" UNIQUE (email);


--
-- Name: Students Students_email_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_email_key96" UNIQUE (email);


--
-- Name: Students Students_loginId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key1" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key10" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key100" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key101" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key102" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key103" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key104" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key105" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key106" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key107" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key108" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key109" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key11" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key110" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key111" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key112" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key113" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key114" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key115" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key116" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key117" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key118" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key119" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key12" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key120" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key121" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key122" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key123" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key124" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key125" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key126" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key127" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key128" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key129" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key13" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key130" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key131" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key132" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key133" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key134" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key135" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key136" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key137" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key138" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key139" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key14" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key140" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key141" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key142" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key143" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key144" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key145" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key146" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key147" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key148" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key149" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key15" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key150" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key151" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key152" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key153" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key154" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key155" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key156" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key157" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key158" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key159" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key16" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key160" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key161" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key162" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key163" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key164" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key165" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key166" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key167" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key168" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key169" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key17" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key170" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key171" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key172" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key173" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key174" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key18" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key19" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key2" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key20" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key21" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key22" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key23" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key24" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key25" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key26" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key27" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key28" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key29" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key3" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key30" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key31" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key32" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key33" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key34" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key35" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key36" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key37" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key38" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key39" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key4" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key40" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key41" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key42" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key43" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key44" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key45" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key46" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key47" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key48" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key49" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key5" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key50" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key51" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key52" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key53" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key54" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key55" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key56" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key57" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key58" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key59" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key6" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key60" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key61" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key62" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key63" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key64" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key65" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key66" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key67" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key68" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key69" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key7" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key70" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key71" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key72" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key73" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key74" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key75" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key76" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key77" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key78" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key79" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key8" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key80" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key81" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key82" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key83" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key84" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key85" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key86" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key87" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key88" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key89" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key9" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key90" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key91" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key92" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key93" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key94" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key95" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key96" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key97" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key98" UNIQUE ("loginId");


--
-- Name: Students Students_loginId_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_loginId_key99" UNIQUE ("loginId");


--
-- Name: Students Students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_pkey" PRIMARY KEY (id);


--
-- Name: Teachers Teachers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key1" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key10" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key11" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key12" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key13" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key14" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key15" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key16" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key17" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key18" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key19" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key2" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key20" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key21" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key22" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key23" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key24" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key25" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key26" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key27" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key28" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key29" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key3" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key30" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key31" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key32" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key33" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key34" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key35" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key36" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key37" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key38" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key39" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key4" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key40" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key41" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key42" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key43" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key44" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key45" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key46" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key47" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key48" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key49" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key5" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key50" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key51" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key52" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key53" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key54" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key55" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key56" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key57" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key58" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key59" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key6" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key60" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key61" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key62" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key63" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key64" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key65" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key66" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key67" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key68" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key69" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key7" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key70" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key71" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key72" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key73" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key74" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key75" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key76" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key77" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key78" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key79" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key8" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key80" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key81" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key82" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key83" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key84" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key85" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key86" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key87" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key88" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key89" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key9" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key90" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key91" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key92" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key93" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key94" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key95" UNIQUE (email);


--
-- Name: Teachers Teachers_email_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_email_key96" UNIQUE (email);


--
-- Name: Teachers Teachers_loginId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key1" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key10; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key10" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key100; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key100" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key101; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key101" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key102; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key102" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key103; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key103" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key104; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key104" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key105; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key105" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key106; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key106" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key107; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key107" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key108; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key108" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key109; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key109" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key11; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key11" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key110; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key110" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key111; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key111" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key112; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key112" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key113; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key113" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key114; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key114" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key115; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key115" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key116; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key116" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key117; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key117" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key118; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key118" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key119; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key119" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key12; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key12" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key120; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key120" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key121; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key121" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key122; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key122" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key123; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key123" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key124; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key124" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key125; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key125" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key126; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key126" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key127; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key127" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key128; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key128" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key129; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key129" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key13; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key13" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key130; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key130" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key131; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key131" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key132; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key132" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key133; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key133" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key134; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key134" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key135; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key135" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key136; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key136" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key137; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key137" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key138; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key138" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key139; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key139" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key14; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key14" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key140; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key140" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key141; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key141" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key142; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key142" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key143; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key143" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key144; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key144" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key145; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key145" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key146; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key146" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key147; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key147" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key148; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key148" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key149; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key149" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key15; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key15" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key150; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key150" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key151; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key151" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key152; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key152" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key153; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key153" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key154; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key154" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key155; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key155" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key156; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key156" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key157; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key157" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key158; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key158" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key159; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key159" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key16; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key16" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key160; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key160" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key161; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key161" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key162; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key162" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key163; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key163" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key164; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key164" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key165; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key165" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key166; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key166" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key167; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key167" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key168; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key168" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key169; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key169" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key17; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key17" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key170; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key170" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key171; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key171" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key172; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key172" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key173; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key173" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key174; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key174" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key18; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key18" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key19; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key19" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key2" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key20; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key20" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key21; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key21" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key22" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key23" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key24; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key24" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key25; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key25" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key26; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key26" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key27; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key27" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key28; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key28" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key29; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key29" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key3" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key30; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key30" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key31; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key31" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key32; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key32" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key33" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key34; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key34" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key35; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key35" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key36; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key36" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key37; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key37" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key38" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key39; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key39" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key4" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key40" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key41; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key41" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key42; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key42" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key43; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key43" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key44; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key44" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key45; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key45" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key46; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key46" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key47" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key48" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key49; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key49" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key5" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key50; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key50" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key51; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key51" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key52; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key52" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key53; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key53" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key54; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key54" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key55; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key55" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key56; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key56" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key57; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key57" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key58; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key58" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key59; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key59" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key6" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key60; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key60" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key61; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key61" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key62; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key62" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key63; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key63" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key64; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key64" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key65; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key65" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key66; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key66" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key67; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key67" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key68; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key68" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key69; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key69" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key7" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key70" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key71; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key71" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key72; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key72" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key73" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key74; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key74" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key75; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key75" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key76; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key76" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key77; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key77" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key78; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key78" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key79; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key79" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key8" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key80; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key80" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key81" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key82; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key82" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key83; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key83" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key84" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key85; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key85" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key86; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key86" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key87; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key87" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key88; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key88" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key89; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key89" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key9" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key90" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key91; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key91" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key92" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key93" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key94; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key94" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key95; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key95" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key96" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key97; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key97" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key98; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key98" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_loginId_key99; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_loginId_key99" UNIQUE ("loginId");


--
-- Name: Teachers Teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teachers"
    ADD CONSTRAINT "Teachers_pkey" PRIMARY KEY (id);


--
-- Name: Tokens Tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tokens"
    ADD CONSTRAINT "Tokens_pkey" PRIMARY KEY (id);


--
-- Name: UniversityPercentages UniversityPercentages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UniversityPercentages"
    ADD CONSTRAINT "UniversityPercentages_pkey" PRIMARY KEY (id);


--
-- Name: ItQualificationResults ItQualificationResults_ItQualificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ItQualificationResults"
    ADD CONSTRAINT "ItQualificationResults_ItQualificationId_fkey" FOREIGN KEY ("ItQualificationId") REFERENCES public."ItQualifications"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ItQualificationResults ItQualificationResults_skillId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ItQualificationResults"
    ADD CONSTRAINT "ItQualificationResults_skillId_fkey" FOREIGN KEY ("skillId") REFERENCES public."Skills"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ItQualifications ItQualifications_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ItQualifications"
    ADD CONSTRAINT "ItQualifications_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JapanLanguageTests JapanLanguageTests_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."JapanLanguageTests"
    ADD CONSTRAINT "JapanLanguageTests_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LessonResults LessonResults_creditId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LessonResults"
    ADD CONSTRAINT "LessonResults_creditId_fkey" FOREIGN KEY ("creditId") REFERENCES public."Credits"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LessonResults LessonResults_semesterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LessonResults"
    ADD CONSTRAINT "LessonResults_semesterId_fkey" FOREIGN KEY ("semesterId") REFERENCES public."Semesters"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lessons Lessons_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lessons"
    ADD CONSTRAINT "Lessons_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SelectedStudents SelectedStudents_RecruitorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SelectedStudents"
    ADD CONSTRAINT "SelectedStudents_RecruitorId_fkey" FOREIGN KEY ("RecruitorId") REFERENCES public."Recruitors"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SelectedStudents SelectedStudents_StudentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SelectedStudents"
    ADD CONSTRAINT "SelectedStudents_StudentId_fkey" FOREIGN KEY ("StudentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Semesters Semesters_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Semesters"
    ADD CONSTRAINT "Semesters_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lessons"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Specialisations Specialisations_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialisations"
    ADD CONSTRAINT "Specialisations_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."Sections"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StudentParents StudentParents_ParentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudentParents"
    ADD CONSTRAINT "StudentParents_ParentId_fkey" FOREIGN KEY ("ParentId") REFERENCES public."Parents"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudentParents StudentParents_StudentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudentParents"
    ADD CONSTRAINT "StudentParents_StudentId_fkey" FOREIGN KEY ("StudentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Students Students_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."Groups"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UniversityPercentages UniversityPercentages_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UniversityPercentages"
    ADD CONSTRAINT "UniversityPercentages_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."Students"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

